#!/bin/sh
# with gdb server
./qemu-aarch64_7fe0533c5ed61f9e90896ddbb95d0f1a -g 10001 -nx -L ./ ./babyarm64_6fecf89af35702a60e1a2b0f8debdd3d
