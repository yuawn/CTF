<?php
function show_footer() { ?>
<hr>
<small>Hope that you like this damn vulnerable dafuqManager :)</small>
</center></body>
</html><?php
}
